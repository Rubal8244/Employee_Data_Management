// Combined server.js (previously index.js and server.js)
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;
const USERS_FILE = path.join(__dirname, 'users.json');
const EMPLOYEES_FILE = path.join(__dirname, 'employees.json');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Middleware to log requests
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// Validate signup data
const validateSignupData = (req, res, next) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).send('All fields (username, email, password) are required!');
    }

    next();
};

// Serve signup page as the default page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

// Handle signup form submission
app.post('/signup', validateSignupData, (req, res) => {
    const userData = `Username: ${req.body.username}, Email: ${req.body.email}, Password: ${req.body.password}\n`;
    fs.appendFile('user_data.txt', userData, (err) => {
        if (err) throw err;
        console.log('User data saved!');
    });

    res.send('Signup successful! Your data has been saved.');
});

// Handle adding new employees
app.post('/add-employee', (req, res) => {
    const { name, salary } = req.body;

    if (!name || !salary) {
        return res.status(400).send('Name and salary are required!');
    }

    const employeeData = { name, salary };

    fs.readFile(EMPLOYEES_FILE, 'utf8', (err, data) => {
        let employees = [];
        if (!err && data) {
            employees = JSON.parse(data);
        }
        employees.push(employeeData);
        fs.writeFile(EMPLOYEES_FILE, JSON.stringify(employees, null, 2), (err) => {
            if (err) {
                return res.status(500).send('Error saving employee data');
            }
            res.redirect('/'); // Redirect back to the form page
        });
    });
});

// Route to display all employees
app.get('/employees', (req, res) => {
    fs.readFile(EMPLOYEES_FILE, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading employee data');
        }
        const employees = JSON.parse(data);
        res.json(employees);
    });
});




app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});