const fs = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, 'employees.json');

const readEmployees = () => {
    if (!fs.existsSync(DATA_FILE)) {
        console.log('No data file found.');
        return [];
    }
    return JSON.parse(fs.readFileSync(DATA_FILE));
};

const displayEmployees = () => {
    const employees = readEmployees();
    if (employees.length === 0) {
        console.log('No employees found.');
        return;
    }

    console.log('Employee Data:');
    let totalSalary = 0;
    employees.forEach((employee, index) => {
        console.log(`${index + 1}. Name: ${employee.name}, Salary: Rs: ${employee.salary}`);
        totalSalary += Number(employee.salary); // Ensure salary is treated as a number
    });

    console.log(`Total Salary: Rs: ${totalSalary}`);
};

displayEmployees();